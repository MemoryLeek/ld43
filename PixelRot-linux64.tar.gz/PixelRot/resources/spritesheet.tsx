<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="spritesheet" tilewidth="32" tileheight="32" tilecount="4096" columns="64">
 <image source="spritesheet.png" width="2048" height="2048"/>
</tileset>
